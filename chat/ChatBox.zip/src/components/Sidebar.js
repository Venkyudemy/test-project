import React from "react";
 
const Sidebar = () => {
  return (
    <div className="sidebar">
      <h3>Workflows</h3>
      <ul>
        <li>Apply Leave</li>
        <li>Create PO</li>
        <li>Update Inventory</li>
        <li>AI Assistant</li>
      </ul>
    </div>
  );
};
 
export default Sidebar;